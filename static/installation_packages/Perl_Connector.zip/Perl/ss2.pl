#! /usr/bin/ruby
require './ss2_config.pl';
use Math::Round;
use Data::UUID;
use JSON;
use URI::Escape;
use WWW::Curl::Easy;
use Time::HiRes qw(gettimeofday);
use CGI;
$query = new CGI;
#Request Variables
$ShieldsquareRequest_zpsbd0 = false;
$ShieldsquareRequest_zpsbd1 = "";
$ShieldsquareRequest_zpsbd2 = "";
$ShieldsquareRequest_zpsbd3 = "";
$ShieldsquareRequest_zpsbd4 = "";
$ShieldsquareRequest_zpsbd5 = "";
$ShieldsquareRequest_zpsbd6 = "";
$ShieldsquareRequest_zpsbd7 = "";
$ShieldsquareRequest_zpsbd8 = "";
$ShieldsquareRequest_zpsbd9 = "";
$ShieldsquareRequest_zpsbda = "";
$ShieldsquareRequest__uzma = "";
$ShieldsquareRequest__uzmb = 0;
$ShieldsquareRequest__uzmc = "";
$ShieldsquareRequest__uzmd = 0;

#Curl Response Variables
$ShieldsquareCurlResponseCode_error_string = "";
$ShieldsquareCurlResponseCode_responsecode = 0;

#Response Variables
$ShieldsquareResponse_pid = "";
$ShieldsquareResponse_responsecode= 0;
$ShieldsquareResponse_url = "";
$ShieldsquareResponse_reason ="";

#Codes Variables
$ShieldsquareCodes_ALLOW   = 0;
$ShieldsquareCodes_MONITOR = 1;
$ShieldsquareCodes_CAPTCHA = 2;
$ShieldsquareCodes_BLOCK   = 3;
$ShieldsquareCodes_FFD   = 3;
$ShieldsquareCodes_ALLOW_EXP = -1;


sub shieldsquare_ValidateRequest($shieldsquare_username,$shieldsquare_calltype,$shieldsquare_pid)
{
	$shieldsquare_low  = 10000;
	$shieldsquare_high = 99999;
	$shieldsquare_a = 1;
	$shieldsquare_b = 3;
	$shieldsquare_c = 7;
	$shieldsquare_d = 1;
	$shieldsquare_e = 5;
	$shieldsquare_f = 10;
	$shieldsquare_service_url = 'http://'.$Ss2_Config_ss2_domain.'/getRequestData';
	$shieldsquare_time=time();
	$shieldsquare_ex_time=time() +(3600*24*365*10);
	if($Ss2_Config_timeout_type== 1) 
	{
		if($Ss2_Config_timeout_value > 1)
		{
			print "Content-type: text/html \n\n";
			print "  \n";
			print 'ShieldSquare Timeout cant be greater then 1 seconds';
			exit;
		}
	}
	else
	{	if($Ss2_Config_timeout_value > 1000)
		{
			print "Content-type: text/html \n\n";
			print "  \n";
			print 'ShieldSquare Timeout cant be greater then 1000 Milli seconds';
			exit;
		}	
	}
	if($shieldsquare_calltype == 1)
	{
		$shieldsquare_pid = shieldsquare_generate_pid($Ss2_Config_sid);
	}
	else
	{
		if(length($shieldsquare_pid) == 0)
		{
			print "Content-type: text/html \n\n";
			print "  \n";
			print 'PID Cant be null';
			exit;
		}
	}
	#Retrieving Cookies
	$rcvd_cookies = $ENV{'HTTP_COOKIE'};
	@cookies = split /;/, $rcvd_cookies;
	foreach $cookie ( @cookies )
	{
		($key, $val) = split(/=/, $cookie); # splits on the first =.
		$key =~ s/^\s+//;
		$val =~ s/^\s+//;
		$key =~ s/\s+$//;
		$val =~ s/\s+$//;
		if( $key eq '__uzma' )
		{
			$Cookie__uzma = $val;
		}
		elsif($key eq '__uzmb')
		{
			$Cookie__uzmb = $val;
		}
		elsif($key eq "__uzmc")
		{
			$Cookie__uzmc = $val;
		}
		elsif($key eq "__uzmd")
		{
			$Cookie__uzmd = $val;
		}
		elsif($key eq $Ss2_Config_sessid)
		{
			$Cookie__sessid = $val;
		}
	}
	if($Cookie__uzma ne "")
	{
		$shieldsquare_lastaccesstime =  $Cookie__uzmd;		
		$shieldsquare_uzmc=0;
		$shieldsquare_uzmc= $Cookie__uzmc;
		$shieldsquare_uzmc=substr($shieldsquare_uzmc, $shieldsquare_e, length($shieldsquare_uzmc) - $shieldsquare_f);
		$shieldsquare_a = (int($shieldsquare_uzmc)-$shieldsquare_c)/$shieldsquare_b + $shieldsquare_d;
		$shieldsquare_uzmc= ($shieldsquare_low + round(rand($shieldsquare_high))).($shieldsquare_c+$shieldsquare_a*$shieldsquare_b).($shieldsquare_low + round(rand($shieldsquare_high)));
		$cookie5 = $query->cookie(-name=>'__uzmc',-value=>$shieldsquare_uzmc,-expires=>$shieldsquare_ex_time);
		$cookie6 = $query->cookie(-name=>'__uzmd',-value=>$shieldsquare_time,-expires=>$shieldsquare_ex_time);
		print $query->header(-cookie=>[$cookie5,$cookie6]);
		$ShieldsquareRequest__uzma = $Cookie__uzma;
		$ShieldsquareRequest__uzmb = $Cookie__uzmb;
		$ShieldsquareRequest__uzmc = $shieldsquare_uzmc;
		$ShieldsquareRequest__uzmd = $shieldsquare_lastaccesstime;
	}
	else
	{
		$ug    = Data::UUID->new;
		$uuid1 = $ug->create();
		$shieldsquare_uzma=$uuid1;
		$shieldsquare_lastaccesstime = time();
		$shieldsquare_uzmc= ($shieldsquare_low + round(rand($shieldsquare_high))).($shieldsquare_c+$shieldsquare_a*$shieldsquare_b).($shieldsquare_low + round(rand($shieldsquare_high)));
		$cookie1 = $query->cookie(-name=>'__uzma',-value=>$shieldsquare_uzma,-expires=>$shieldsquare_ex_time);
		$cookie2 = $query->cookie(-name=>'__uzmb',-value=>$shieldsquare_time,-expires=>$shieldsquare_ex_time);
		$cookie3 = $query->cookie(-name=>'__uzmc',-value=>$shieldsquare_uzmc,-expires=>$shieldsquare_ex_time);
		$cookie4 = $query->cookie(-name=>'__uzmd',-value=>$shieldsquare_time,-expires=>$shieldsquare_ex_time);
		print $query->header(-cookie=>[$cookie1,$cookie2,$cookie3,$cookie4]);
		$ShieldsquareRequest__uzma = $shieldsquare_uzma;
		$ShieldsquareRequest__uzmb = time();
		$ShieldsquareRequest__uzmc = $shieldsquare_uzmc;
		$ShieldsquareRequest__uzmd = $shieldsquare_lastaccesstime;
	}
	if($Ss2_Config_mode eq 'Active')
	{
		$ShieldsquareRequest_zpsbd0 = 'true';
	}
	else
	{
		$ShieldsquareRequest_zpsbd0 = 'false';
	}
	$ShieldsquareRequest_zpsbd1 = $Ss2_Config_sid;
	$ShieldsquareRequest_zpsbd2 = $shieldsquare_pid;
	$ShieldsquareRequest_zpsbd3 = $ENV{'HTTP_REFERER'};
	$ShieldsquareRequest_zpsbd4 = $ENV{'REQUEST_URI'};
	$ShieldsquareRequest_zpsbd5 = $Cookie__sessid;
	$ShieldsquareRequest_zpsbd6 = $ENV{$Ss2_Config_ipaddress};
	$ShieldsquareRequest_zpsbd7 = $ENV{'HTTP_USER_AGENT'};
	$ShieldsquareRequest_zpsbd8 = $shieldsquare_calltype;
	$ShieldsquareRequest_zpsbd9 = $shieldsquare_username;
	$ShieldsquareRequest_zpsbda = time();
	%my_hash = ('_zpsbd0' => $ShieldsquareRequest_zpsbd0,'_zpsbd1' => $ShieldsquareRequest_zpsbd1,'_zpsbd2' => $ShieldsquareRequest_zpsbd2,'_zpsbd3' => $ShieldsquareRequest_zpsbd3,'_zpsbd4' => $ShieldsquareRequest_zpsbd4,'_zpsbd5' => $ShieldsquareRequest_zpsbd5,'_zpsbd6' => $ShieldsquareRequest_zpsbd6,'_zpsbd7' => $ShieldsquareRequest_zpsbd7,'_zpsbd8' => $ShieldsquareRequest_zpsbd8,'_zpsbd9' => $ShieldsquareRequest_zpsbd9,'_zpsbda' => $ShieldsquareRequest_zpsbda,'__uzma' => $ShieldsquareRequest__uzma,'__uzmb' => $ShieldsquareRequest__uzmb,'__uzmc' => $ShieldsquareRequest__uzmc,'__uzmd' => $ShieldsquareRequest__uzmd);
	$shieldsquare_json_obj = encode_json \%my_hash;
	$ShieldsquareResponse_pid =$shieldsquare_pid;
	$ShieldsquareResponse_url =$Ss2_Config_js_url;

	if($Ss2_Config_mode eq 'Active')
	{
		%shieldsquareCurlResponseCode=shieldsquare_post_sync($shieldsquare_service_url,$shieldsquare_json_obj,$Ss2_Config_timeout_value);
		if($shieldsquareCurlResponseCode{'response'} != 200)
		{
			$ShieldsquareResponse_responsecode = $ShieldsquareCodes_ALLOW_EXP;
			$ShieldsquareResponse_reason = $shieldsquareCurlResponseCode{'output'};
		}
		else
		{
			$shieldsquareResponse_from_ss = decode_json($shieldsquareCurlResponseCode{'output'});
			$ShieldsquareResponse_dynamic_JS = $shieldsquareResponse_from_ss->{'dynamic_JS'};
			$n=int($shieldsquareResponse_from_ss->{'ssresp'});
			if($n==0)
			{
				$ShieldsquareResponse_responsecode = $ShieldsquareCodes_ALLOW;
			}
			elsif($n==1)
			{
				$ShieldsquareResponse_responsecode = $ShieldsquareCodes_MONITOR;
			}
			elsif($n==2)
			{
				$ShieldsquareResponse_responsecode = $ShieldsquareCodes_CAPTCHA;
			}
			elsif($n==3)
			{
				$ShieldsquareResponse_responsecode = $ShieldsquareCodes_BLOCK;
			}
			elsif($n==4)
			{
				$ShieldsquareResponse_responsecode = $ShieldsquareCodes_FFD;
			}
			else
			{
				$ShieldsquareResponse_responsecode = $ShieldsquareCodes_ALLOW_EXP;
				$ShieldsquareResponse_reason = $shieldsquareCurlResponseCode['output'];
			}
		}
	}
	else
	{
		if($Ss2_Config_async_http_post eq 'true')
		{
			%asyncresponse=shieldsquare_post_async($shieldsquare_service_url, $shieldsquare_json_obj,$Ss2_Config_timeout_value);
			if($asyncresponse{'response'} == -1)
			{
				$ShieldsquareResponse_responsecode = $ShieldsquareCodes_ALLOW_EXP;
				$ShieldsquareResponse_reason = "Request Timed Out/Server Not Reachable";
			}
			else
			{
				$ShieldsquareResponse_responsecode = $ShieldsquareCodes_ALLOW;
			}
		}
		else
		{
			%syncresponse=shieldsquare_post_sync($shieldsquare_service_url,\%my_hash,$Ss2_Config_timeout_value);
			if($syncresponse{'response'} != 200)
			{
				$ShieldsquareResponse_responsecode = $ShieldsquareCodes_ALLOW_EXP;
				$ShieldsquareResponse_reason = $syncresponse{'output'};
			}
			else
			{
				$ShieldsquareResponse_responsecode = $ShieldsquareCodes_ALLOW;
			}
		}
		$ShieldsquareResponse_dynamic_JS = "var __uzdbm_c = 2+2";
	}

	%shieldsquareResponse = ("pid" => $ShieldsquareResponse_pid, "responsecode" => $ShieldsquareResponse_responsecode,"url" => $ShieldsquareResponse_url,"reason" => $ShieldsquareResponse_reason,"dynamic_JS" =>$ShieldsquareResponse_dynamic_JS);
	return %shieldsquareResponse;
}

sub shieldsquare_post_async($url, $payload, $timeout)
{
#	my $filename = 'input.txt';
#	open(my $fh, '>', $filename) or die "Could not open file '$filename' $!";
	my ($url, $payload, $timeout) = @_;
	$cmd = 'curl -X POST  -H "Accept: Application/json" -H "Content-Type: application/json" -m '. $timeout . ' ' . $url . " -d '". uri_escape($payload) . "'";
	$output=`$cmd`;
	$result = $?;
	%response=("response"=>$result,"output"=>$output);
#	print $fh $output;
#	close $fh;
	return $response;
}
sub shieldsquare_post_sync
{
	# Sendind the Data to the ShieldSquare Server
	my ($url, $payload, $timeout) = @_;
	$payload=uri_escape($payload);
	my $curl = WWW::Curl::Easy->new;
	$curl->setopt(CURLOPT_HEADER,1);
        $curl->setopt(CURLOPT_URL, $url);
	$curl->setopt(CURLOPT_TIMEOUT, $timeout);
	$curl->setopt(CURLOPT_POST, 1);
	$curl->setopt(CURLOPT_POSTFIELDS, $payload);
        my $response_body;
        $curl->setopt(CURLOPT_WRITEDATA,\$response_body);
	eval
	{
		my $retcode = $curl->perform;
		my $response_code=$curl->getinfo(CURLINFO_HTTP_CODE);
		if($response_code==200)
			{
				my $posX=index($response_body,'{');
				my $posY=length($response_body)-$posX;
				my $response_str=substr($response_body,$posX,$posY);
				%response=("response"=>200,"output"=>$response_str);
			}
		else
			{
				%response=("response"=>0,"output"=>"Request Timed Out/Server Not Reachable");
			}
	};
	if ($@) 
	{
		%response=("response"=>0,"output"=>"Request Timed Out/Server Not Reachable");
	}
	return %response;
}
sub microtime{
	my $asFloat = 0;
	if(@_){
		$asFloat = shift;
	}
	(my $epochseconds, my $microseconds) = gettimeofday;
	if($asFloat){
		while(length("$microseconds") < 6){
			$microseconds = "0$microseconds";
		}
		$microtime = "$epochseconds.$microseconds";
	} else {
		$microtime = "$epochseconds $microseconds";
	}
	return $microtime;
}
sub shieldsquare_generate_pid
{
	$t=microtime();
	@dt=split(" ",$t);
	@p = split("-",$Ss2_Config_sid);
	$sid_min = hex($p[3]);
	return sprintf('%08s-%04x-%04s-%04s-%04x%04x%04x', shieldsquare_IP2Hex(),$sid_min,substr("00000000".hex($dt[1]), -4),substr("0000".hex(round($dt[0] * 65536)), -4),rand(0xffff), rand(0xffff), rand(0xffff));
}

sub shieldsquare_IP2Hex
{
	$ip=$ENV{$Ss2_Config_ipaddress};
	@part=split('\.',$ip);
	for ($i = 0; $i <= scalar(@part)-1; $i++)
	{
		$str = sprintf("0x%x",$part[$i]);
		$hex .= substr("0".$str, -2);
	}
	return $hex;
}
