#! /usr/bin/perl

require './ss2.pl';
$shieldsquare_userid = ""; # Enter the UserID of the user
$shieldsquare_calltype = 1;
$shieldsquare_pid = "";
%shieldsquare_response=shieldsquare_ValidateRequest($shieldsquare_userid,$shieldsquare_calltype,$shieldsquare_pid);
print "Content-type: text/html \n\n";
print "  \n";
print "<html>  \n";
print "<head>  \n";
print "<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />  \n";
print "<meta http-equiv='Content-Language' content='en' />  \n";
print "<title>Sample Home Page</title>  \n";
print "</head>  \n";
print "<body>  \n";
if($shieldsquare_response{"responsecode"} == 0)
{
	print "Allow the user request \n";
}
elsif($shieldsquare_response{"responsecode"} == 1)
{
	print "Monitor this Traffic \n";
}
elsif($shieldsquare_response{"responsecode"} == 2)
{
	print "Show CAPTCHA before displaying the content \n";
}
elsif($shieldsquare_response{"responsecode"} == 3)
{
	print "Block This request \n";
}
elsif($shieldsquare_response{"responsecode"} == 4)
{
	print "Feed Fake Data \n";
}
elsif($shieldsquare_response{"responsecode"} == -1)
{
	print "Curl Error - " . $shieldsquare_response{"reason"} . "<BR>";
	print "Please reach out to ShieldSquare support team for assistance <BR>";
	print "Allow the user request \n";
}
print "<script type='text/javascript'>  \n";
print "var __uzdbm_a = '" . $shieldsquare_response{"pid"} ."';  \n";
print "var __uzdbm_b = '" . $shieldsquare_response{"url"} ."'; \n";
print $shieldsquare_response{"dynamic_JS"}. " \n";
print "</script>  \n";
print "<script type='text/javascript' src='http://cdn.perfdrive.com/static/browser_detect_min.js'></script>  \n";
print "<h1>  \n";
print "<BR>YOUR CODE GOES HERE  \n";
print "</h1>  \n";
print "</body>  \n";
print "</html>  \n";

