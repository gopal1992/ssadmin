#! /usr/bin/perl
#require './ss2.pl';
use JSON;
local ($buffer, @pairs, $pair, $name, $value, %FORM);
# Read in text
$ENV{'REQUEST_METHOD'} =~ tr/a-z/A-Z/;
if ($ENV{'REQUEST_METHOD'} eq "POST")
{
	read(STDIN, $buffer, $ENV{'CONTENT_LENGTH'});
}
else
{
	$buffer = $ENV{'QUERY_STRING'};
}
require './ss2.pl';
# Split information into name/value pairs
@pairs = split(/&/, $buffer);
foreach $pair (@pairs)
{
	($name, $value) = split(/=/, $pair);
	$value =~ tr/+/ /;
	$value =~ s/%(..)/pack("C", hex($1))/eg;
	$FORM{$name} = $value;
}
$jsonString = $FORM{jsonString};
if($jsonString ne "")
{
	$shieldsquare_service_url = 'http://' . $Ss2_Config_ss2_domain . '/getss2data';
	$shieldsquare_request = decode_json(uri_unescape($jsonString));
	$shieldsquare_request->{"sid"} = $Ss2_Config_sid;
	$shieldsquare_request->{"host"} = $ENV{$Ss2_Config_ipaddress};
	my %shieldsquare_post_hash =();
	foreach my $key ( keys %{$shieldsquare_request} ) {
	$shieldsquare_post_hash{$key}=$shieldsquare_request->{$key};
	}
	$shieldsquare_post_data = encode_json \%shieldsquare_post_hash;
	if($Ss2_Config_async_http_post eq 'true')
	{
		%error_code=shieldsquare_post_async($shieldsquare_service_url,$shieldsquare_post_data,$Ss2_Config_timeout_value);
	}
	else
	{
		%error_code=shieldsquare_post_sync($shieldsquare_service_url,$shieldsquare_post_data, $Ss2_Config_timeout_value);
	}
}
print "Content-type: text/html \n\n";
print '';
