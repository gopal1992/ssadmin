﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SS2WebApp
{
    public static class ss2_config
    {
           /*
	     *  Enter your SID .
	    */
        public static string _sid = "XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX";

	    /*
	     * Sync = true, Async = false
	    */

	    public static bool _sync = false;

	    
	    /*
	     * Timeout in Seconds or Milliseconds
         */

	    public static int _timeout_value = 200;

	    /*
	     * PHPSESSID is the default session ID for PHP, please change it if needed
	    */
        public static string _sessid = "ASP.NET_SessionId";

	    /*
	     * Change this value if your servers are behind a firewall or proxy
	    */
	    public static string _ipaddress = "REMOTE_ADDR";
    }
}
