#! /usr/bin/ruby
require './ss2'

cgi = CGI.new
if cgi.params['jsonString']!=""
	data=cgi.params['jsonString'].to_s
	data.delete! '\\'
	data.delete! '['
	data.delete! ']'
	data=data[1..-1]
	data=data[0..-2]
	shieldsquare_service_url = 'http://' + $Ss2_Config_ss2_domain + '/getss2data'
	shieldsquare_request = JSON.parse(CGI::unescape(data))
	shieldsquare_request["sid"] = $Ss2_Config_sid
	shieldsquare_request["host"] = ENV[$Ss2_Config_ipaddress]
	shieldsquare_post_data = JSON.generate(shieldsquare_request)
	if $Ss2_Config_async_http_post== true
		error_code=shieldsquare_post_async shieldsquare_service_url, shieldsquare_post_data,$Ss2_Config_timeout_value.to_s
	else
		error_code=shieldsquare_post_sync shieldsquare_service_url, shieldsquare_post_data, $Ss2_Config_timeout_value
	end
end
puts "Content-type: text/html"
puts ''
