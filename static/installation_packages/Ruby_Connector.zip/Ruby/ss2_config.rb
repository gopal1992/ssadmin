#! /usr/bin/ruby

#Enter your SID
$Ss2_Config_sid = "XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX"

#Please specify the mode in which you want to operate
#mode = "Active";
#mode = "Monitor";
$Ss2_Config_mode = 'Monitor'

#Asynchronous HTTP Data Post  
#Setting this value to true will reduce the page load time when you are in Monitor mode. 
#This uses Linux CURL to POST the HTTP data using the EXEC command. 
#Note: Enable this only if you are hosting your applications on Linux environments. 
$Ss2_Config_async_http_post = false

#* Timeout in Seconds or Milliseconds (based on the  $_timeout_type value)
$Ss2_Config_timeout_value = 2

$Ss2_Config_timeout_type = 0

#* PHPSESSID is the default session ID for PHP, please change it if needed
$Ss2_Config_sessid = 'SESSID'

#* Change this value if your servers are behind a firewall or proxy
$Ss2_Config_ipaddress = 'REMOTE_ADDR'

#* Enter the URL fo the JavaScript Data Collector
$Ss2_Config_js_url = '/getData.rb'

#* Set the ShieldSquare domain based on your Server Locations
#*    East US        - ss_eus.shieldsquare.net
#*    West US        - ss_wus.shieldsquare.net
#*    India/Asia     - ss_sa.shieldsquare.net
#*    North Europe   - ss_ne.shieldsquare.net
#*    West Europe    - ss_we.shieldsquare.net
$Ss2_Config_ss2_domain = 'prod-cfm1-sa.cloudapp.net:7080'

