<?php
class shieldsquare_config
{
	/*
	 *  Enter your Subscriber id  .
	 */
	public $_sid = "XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX";

	/*

	 * Please specify the mode in which you want to operate
	 * 
	 * public $_mode = "Active";
	 * or
	 * public $_mode = "Monitor";
 	 */
	public $_mode = "Monitor";


    /*
     * Asynchronous HTTP Data Post  

     * Setting this value to true will reduce the page load time when you are in Monitor mode. 
     * This uses Linux CURL to POST the HTTP data using the EXEC command. 
     * Note: Enable this only if you are hosting your applications on Linux environments.   

     */
	public $_async_http_post = true;
		
	
	/*
	 * Curl Timeout in Milliseconds
	 */
	public $_timeout_value = 100;

	/*
	 * PHPSESSID is the default session ID for PHP, please change it if needed
	 */
	public $_sessid = 'PHPSESSID';

	/*
	 * Change this value if your servers are behind a firewall or proxy
	 */
	public $_ipaddress = 'REMOTE_ADDR';

	/*
	 * Enter the relative URL of the JavaScript Data Collector
	 */
	public $_js_url = '/getData.php';

	/*
	 * Set the ShieldSquare domain based on your Server Locations
	 *    US/Europe    	-    'ss_scus.shieldsquare.net'
	 *    India/Asia    -    'ss_sa.shieldsquare.net'
	 */
	public $_ss2_domain = 'ss_sa.shieldsquare.net';
}
?>