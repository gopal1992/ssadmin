﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;
using System.Collections.Specialized;
using System.Text;
using System.Threading;
using System.Text.RegularExpressions;
using System.Web.Script.Serialization;
using System.Net.Http;
using System.Threading.Tasks;
using System.Xml;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;






namespace SS2WebApp
{
    public class ss2
    {
        class HeaderData
        {
            public string Key { get; set; }
            public int Index { get; set; }
            public string Value { get; set; }
        };
        
        //public static List<HeaderData> _list = new List<HeaderData>();
        class shieldsquareRequest
        {
            public bool _zpsbd0;
            public string _zpsbd1;
            public string _zpsbd2;
            public string _zpsbd3;
            public string _zpsbd4;
            public string _zpsbd5;
            public string _zpsbd6;
            public string _zpsbd7;
            public int _zpsbd8;
            public string _zpsbd9;
            public int _zpsbda;
            public string __uzma;
            public long __uzmb;
            public string __uzmc;
            public long __uzmd;

            public shieldsquareRequest()
            {
                _zpsbd0 = false;
                _zpsbd1 = "";
                _zpsbd2 = "";
                _zpsbd3 = "";
                _zpsbd4 = "";
                _zpsbd5 = "";
                _zpsbd6 = "";
                _zpsbd7 = "";
                _zpsbd8 = 0;
                _zpsbd9 = "";
                _zpsbda = 0;
                __uzma = "";
                __uzmb = 0;
                __uzmc = "";
                __uzmd = 0;
            }
        }
        public class shieldsquareResponse
        {
            public string pid;
            public int responsecode;
            public string reason;
            public string url;
            public string dynamic_js;
            public shieldsquareResponse()
            {
                pid = "";
                responsecode = shieldsquareCodes.ALLOW_EXP;
                reason = "";
                url = "";
                dynamic_js = "";
            }
        }

        class shieldsquareCodes
        {
            public static int ALLOW = 0;
            public static int MONITOR = 1;
            public static int CAPTCHA = 2;
            public static int BLOCK = 3;
            public static int FFD = 4;
            public static int ALLOW_EXP = -1;

        }        

        struct response
        {
            public string test { get; set; }
        }

        public class MyGlobals
        {
            public static string jsonStr = ""; // cannot change           
            public static string respStr = ""; // cannot change
        }
        public shieldsquareResponse ShieldSquare_ValidateRequest(HttpRequest q, HttpResponse httpResp, string shieldsquare_username, int shieldsquare_calltype, string shieldsquare_pid)
        {

            
            shieldsquareResponse shieldsquare_response = new shieldsquareResponse();            
            int shieldsquare_low = 10000;            
            int shieldsquare_high = 99999;
            int shieldsquare_a = 1;
            int shieldsquare_b = 3;
            int shieldsquare_c = 7;
            int shieldsquare_d = 1;
            int shieldsquare_e = 5;
            int shieldsquare_f = 10;
            int shieldsquare_time = GetUnixTimestamp(DateTime.Now);
            string sid = ss2_config._sid;
 

            try
            {             

                 string shieldsquare_service_url = "http://" + ss2_config._ss2_domain + "/getRequestData";
                 shieldsquareRequest shieldsquare_request = new shieldsquareRequest();
                 if (ss2_config._timeout_type == 1)
                 {
                     if (ss2_config._timeout_value > 1)
                     {

                     }
                 }
                 else
                 {
                     if (ss2_config._timeout_value > 1000)
                     {

                     }
                 }
                if (shieldsquare_calltype == 1)
                {
                    // only call type 1 will generate a new tid
                    shieldsquare_pid = shieldsquare_generate_tid(q, ss2_config._sid);                    
                    shieldsquare_response.pid = shieldsquare_pid;
                }
                else
                {


                    if (shieldsquare_pid.Length == 0)
                    {
                        //"PID Cant be null"
                        shieldsquare_response.reason = "input parameter TID cannot be null";
                        return shieldsquare_response;
                    }

                }

                Random random = new Random();
                //get shieldsquare cookies 
                if (q.Cookies["__uzma"] != null && q.Cookies["__uzmb"] != null && q.Cookies["__uzmd"] != null)
                {
                    string shieldsquare_lastaccesstime = q.Cookies["__uzmd"].Value;
                    string shieldsquare_uzmc = q.Cookies["__uzmc"] != null ? q.Cookies["__uzmc"].Value : "0";
                    shieldsquare_uzmc = shieldsquare_uzmc.Substring(shieldsquare_e, shieldsquare_uzmc.Length - shieldsquare_f);
                    shieldsquare_a = (int.Parse(shieldsquare_uzmc) - shieldsquare_c) / shieldsquare_b + shieldsquare_d;


                    shieldsquare_uzmc = random.Next(shieldsquare_low, shieldsquare_high).ToString() + (shieldsquare_c + shieldsquare_a * shieldsquare_b).ToString() + random.Next(shieldsquare_low, shieldsquare_high).ToString();

                    HttpCookie uzmcCookie = new HttpCookie("__uzmc");
                    HttpCookie uzmdCookie = new HttpCookie("__uzmd");
                    HttpCookie uzmaCookie = new HttpCookie("__uzma");
                    HttpCookie uzmbCookie = new HttpCookie("__uzmb");

                    uzmcCookie.Value = shieldsquare_uzmc;
                    uzmdCookie.Expires = uzmcCookie.Expires = DateTime.Now.AddSeconds(3600 * 24 * 365 * 10);
                    uzmdCookie.Value = shieldsquare_time.ToString();
                    httpResp.SetCookie(uzmcCookie);
                    httpResp.SetCookie(uzmdCookie);

                    shieldsquare_request.__uzma = q.Cookies["__uzma"].Value;
                    shieldsquare_request.__uzmb = long.Parse(q.Cookies["__uzmb"].Value);
                    shieldsquare_request.__uzmc = shieldsquare_uzmc;
                    shieldsquare_request.__uzmd = long.Parse(shieldsquare_lastaccesstime);
                }
                else
                {
                    string shieldsquare_uzma = "ma" + System.Guid.NewGuid().ToString() + random.Next(1000, 9999);
                    string shieldsquare_lastaccesstime = shieldsquare_time.ToString();
                    string shieldsquare_uzmc = random.Next(shieldsquare_low, shieldsquare_high).ToString() + (shieldsquare_c + shieldsquare_a * shieldsquare_b).ToString() + random.Next(shieldsquare_low, shieldsquare_high).ToString();

                    HttpCookie uzmcCookie = new HttpCookie("__uzmc");
                    HttpCookie uzmdCookie = new HttpCookie("__uzmd");
                    HttpCookie uzmaCookie = new HttpCookie("__uzma");
                    HttpCookie uzmbCookie = new HttpCookie("__uzmb");

                    uzmaCookie.Value = shieldsquare_uzma;
                    uzmdCookie.Value = uzmbCookie.Value = shieldsquare_time.ToString();
                    uzmcCookie.Value = shieldsquare_uzmc;

                    uzmaCookie.Expires = uzmbCookie.Expires = uzmcCookie.Expires = uzmdCookie.Expires = DateTime.Now.AddSeconds(3600 * 24 * 365 * 10);

                    httpResp.Cookies.Add(uzmaCookie);
                    httpResp.Cookies.Add(uzmbCookie);
                    httpResp.Cookies.Add(uzmcCookie);
                    httpResp.Cookies.Add(uzmdCookie);

                    shieldsquare_request.__uzma = shieldsquare_uzma;
                    shieldsquare_request.__uzmb = shieldsquare_time;
                    shieldsquare_request.__uzmc = shieldsquare_uzmc;
                    shieldsquare_request.__uzmd = long.Parse(shieldsquare_lastaccesstime);
                }

                if (ss2_config._mode == "Active")
                {
                    shieldsquare_request._zpsbd0 = true;
                }
                else
                {
                    shieldsquare_request._zpsbd0 = false;
                }
                
                shieldsquare_request._zpsbd1 = ss2_config._sid;
                shieldsquare_request._zpsbd2 = shieldsquare_pid;
                shieldsquare_request._zpsbd3 = q.ServerVariables["HTTP_REFERER"] != null ? q.ServerVariables["HTTP_REFERER"] : "";
                shieldsquare_request._zpsbd4 = q.ServerVariables["REQUEST_URI"] != null ? q.ServerVariables["REQUEST_URI"] : "";
                shieldsquare_request._zpsbd5 = q.Cookies[ss2_config._sessid] != null ? q.Cookies[ss2_config._sessid].Value : "";
                shieldsquare_request._zpsbd6 = q.ServerVariables[ss2_config._ipaddress] != null ? q.ServerVariables[ss2_config._ipaddress] : "";
                shieldsquare_request._zpsbd7 = q.ServerVariables["HTTP_USER_AGENT"] != null ? q.ServerVariables["HTTP_USER_AGENT"] : "";
                shieldsquare_request._zpsbd8 = shieldsquare_calltype;
                shieldsquare_request._zpsbd9 = shieldsquare_username;
                shieldsquare_request._zpsbda = GetUnixTimestamp(DateTime.Now);
                shieldsquare_response.url = ss2_config._js_url;
                shieldsquare_response.pid = shieldsquare_pid;
                var serializer = new JavaScriptSerializer();
                string json = serializer.Serialize(shieldsquare_request);
                MyGlobals.jsonStr = json;
                if(ss2_config._mode=="Active")
                {
                    string[] shieldsquarePostResponse = HttpSyncPost(shieldsquare_service_url, json);
                    if (shieldsquarePostResponse[0] == "false")
                    {
                        shieldsquare_response.responsecode = shieldsquareCodes.ALLOW_EXP;
                        shieldsquare_response.reason = shieldsquarePostResponse[1];
                    }
                    else
                    {
                        //Get the Response code from the Shieldsquare Server.
                        dynamic item = serializer.Deserialize<object>(shieldsquarePostResponse[1]);
                        string ss_resp = item["ssresp"];                                              
                        int iss_resp = int.Parse(ss_resp, System.Globalization.NumberStyles.Integer);
                        shieldsquare_response.dynamic_js = item["dynamic_JS"];                        
                        switch (iss_resp)
                        {
                            case 0:
                                shieldsquare_response.responsecode = shieldsquareCodes.ALLOW;
                                break;
                            case 1:
                                shieldsquare_response.responsecode = shieldsquareCodes.MONITOR;
                                break;
                            case 2:
                                shieldsquare_response.responsecode = shieldsquareCodes.CAPTCHA;
                                break;
                            case 3:
                                shieldsquare_response.responsecode = shieldsquareCodes.BLOCK;
                                break;
                            case 4:
                                shieldsquare_response.responsecode = shieldsquareCodes.FFD;
                                break;
                            default:
                                shieldsquare_response.responsecode = shieldsquareCodes.ALLOW_EXP;
                                shieldsquare_response.reason = shieldsquarePostResponse[1];
                                break;
                        }                        
                    }

                }
                else
                {
                    if(ss2_config._async_http_post==true)
                    {
                        string[] shieldsquarePostResponse = HttpAsyncPost(shieldsquare_service_url, json);
                        if(shieldsquarePostResponse[0] == "false")
				        {
                            shieldsquare_response.responsecode = shieldsquareCodes.ALLOW_EXP;
                            shieldsquare_response.reason = shieldsquarePostResponse[1];
                        }
			            else
                        {
                            shieldsquare_response.responsecode = shieldsquareCodes.ALLOW;                            
                        }
				
                    }
                    else
                    {
                        string[] shieldsquarePostResponse = HttpSyncPost(shieldsquare_service_url, json);
                        if (shieldsquarePostResponse[0] == "false")
                        {
                            shieldsquare_response.responsecode = shieldsquareCodes.ALLOW_EXP;
                            shieldsquare_response.reason = shieldsquarePostResponse[1];
                        }
                        else
                        {
                            shieldsquare_response.responsecode = shieldsquareCodes.ALLOW;                         
                        }
                    }
                    shieldsquare_response.dynamic_js = "var __uzdbm_c = 2+2";
                }

                
                //Copy the response code from the server
                
                


            }
            catch (Exception ex)
            {
                shieldsquare_response.reason = ex.Message;
                shieldsquare_response.responsecode = shieldsquareCodes.ALLOW_EXP;
            }

            return shieldsquare_response;
        }




        

        public string[] HttpSyncPost(string URI, string Parameters)
        {
             // Create a request using a URL that can receive a post.            
            //System.Net.WebRequest request = System.Net.WebRequest.Create(URI);

            System.Net.HttpWebRequest request = (System.Net.HttpWebRequest)System.Net.WebRequest.Create(URI);
            request.KeepAlive = false;
            
            // Set the Method property of the request to POST.
            request.Method = "POST";
            //.Timeout = time spent trying to establish a connection (not including lookup time) 
            //.ReadWriteTimeout = time spent trying to read or write data after connection established
            request.Timeout = ss2_config._timeout_value;
            
            // request.ReadWriteTimeout = ss2_config._timeout_value;
            // Create POST data and convert it to a byte array.
        
            byte[] byteArray = System.Text.Encoding.UTF8.GetBytes(Parameters);
            // Set the ContentType property of the WebRequest.
            request.ContentType = "application/x-www-form-urlencoded";
            // Set the ContentLength property of the WebRequest.
            request.ContentLength = byteArray.Length;
            // Get the request stream.
            string responseFromServer = "{\"ssresp\":\"-1\"}";
            System.IO.StreamReader reader = null;
            System.IO.Stream dataStream = null;
            System.Net.WebResponse response = null;
            string[] syncresponse = new string[2];
            try
            {
                dataStream = request.GetRequestStream();
                // Write the data to the request stream.
                dataStream.Write(byteArray, 0, byteArray.Length);
                // Close the Stream object.
                
                // Get the response.
                System.Net.HttpWebResponse respon = (System.Net.HttpWebResponse)request.GetResponse();
                // Display the status.
                    
                //Console.WriteLine();
                // Get the stream containing content returned by the server.
                dataStream = respon.GetResponseStream();
                // Open the stream using a StreamReader for easy access.
                reader = new System.IO.StreamReader(dataStream);
                // Read the content.
                responseFromServer = reader.ReadToEnd();
                syncresponse[0] = "true";
                syncresponse[1] = responseFromServer;
                dataStream.Close();
            }
            catch (Exception ex)
            {

                // Clean up the streams.
                if (reader != null)
                {
                    reader.Close();
                }
                if (dataStream != null)
                {
                    dataStream.Close();
                }
                if (response != null)
                {
                    response.Close();
                }
                syncresponse[0] = "false";
                syncresponse[1] = "Request Timed Out/Server Not Reachable";
                //throw;

            }
            // Clean up the streams.
            if (reader != null)
            {
                reader.Close();
            }
            if (dataStream != null)
            {
                dataStream.Close();
            }
            if (response != null)
            {
                response.Close();
            }
            return syncresponse;
        }
        private static ManualResetEvent allDone = new ManualResetEvent(false);

        public string[] HttpAsyncPost(string URI, string Parameters)
        {
            MyGlobals.jsonStr = Parameters;
            //System.Net.WebRequest request = System.Net.WebRequest.Create(URI);
            System.Net.HttpWebRequest request = (System.Net.HttpWebRequest)System.Net.WebRequest.Create(URI);
            request.KeepAlive = false;

            // Set the Method property of the request to POST.
            request.Method = "POST";
            //.Timeout = time spent trying to establish a connection (not including lookup time) 
            //.ReadWriteTimeout = time spent trying to read or write data after connection established
            
            // Set the ContentType property of the WebRequest.
            request.ContentType = "application/x-www-form-urlencoded";
            // Set the ContentLength property of the WebRequest.
            string[] response=new string[2];
            try
            {
                request.BeginGetRequestStream(new AsyncCallback(GetRequestStreamCallback), request);
                allDone.WaitOne(ss2_config._timeout_value);
                long responseLen = MyGlobals.respStr.Length;
                
                
                if (responseLen != 0)
                {
                    response[0] = "true";
                    response[1] = "";
                }
                else
                {
                    response[0] = "false";
                    response[1] = "Request Timed Out / Server Not Reachable";
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
           

            // request.ReadWriteTimeout = ss2_config._timeout_value;
            // Create POST data and convert it to a byte array.

          
            // Get the request stream.

            return response;
            // Clean up the streams.
          
        }
        private static void GetRequestStreamCallback(IAsyncResult asynchronousResult)
        {
            
            System.Net.HttpWebRequest request = (System.Net.HttpWebRequest)asynchronousResult.AsyncState;
            
            // End the operation
            Stream postStream = request.EndGetRequestStream(asynchronousResult);

            
            string postData = MyGlobals.jsonStr;

            // Convert the string into a byte array. 
            byte[] byteArray = System.Text.Encoding.UTF8.GetBytes(postData);

            // Write to the request stream.
            postStream.Write(byteArray, 0, postData.Length);
            postStream.Close();

            // Start the asynchronous operation to get the response
            request.BeginGetResponse(new AsyncCallback(GetResponseCallback), request);
        }
        private static void GetResponseCallback(IAsyncResult asynchronousResult)
        {
            
            System.Net.HttpWebRequest request = (System.Net.HttpWebRequest)asynchronousResult.AsyncState;
            request.Timeout = ss2_config._timeout_value;
            // End the operation
            System.Net.HttpWebResponse respon = (System.Net.HttpWebResponse)request.EndGetResponse(asynchronousResult);
            Stream streamResponse = respon.GetResponseStream();
            StreamReader streamRead = new StreamReader(streamResponse);
            string responseString = streamRead.ReadToEnd();
            MyGlobals.respStr = responseString;
            
            // Close the stream object
            streamResponse.Close();
            streamRead.Close();

            // Release the HttpWebResponse
            respon.Close();
            allDone.Set();
        }
        public string shieldsquare_generate_tid(HttpRequest q, string shieldsquare_sid)
        {
            DateTime now = DateTime.Now;
            int t = GetUnixTimestamp(now);
            string[] sipParts = shieldsquare_sid.Split('-');
            String sid_min = sipParts[3];
            // String num = sipParts[3];
            Random random = new Random();
            int num = random.Next(4096, 39321); //specified range to get 4 didgit Hex number
            string timeHex = t.ToString("X");
            string tid = shieldsquare_IP2Hex(q) + "-" +
                 sid_min + "-" +
                 timeHex[timeHex.Length - 1] +
                 timeHex[timeHex.Length - 2] +
                 timeHex[timeHex.Length - 3] +
                 timeHex[timeHex.Length - 4] + "-" +
                random.Next(4096, 39321).ToString("X") + "-" +
                    random.Next(4096, 39321).ToString("X") +
                    random.Next(4096, 39321).ToString("X") +
                    random.Next(4096, 39321).ToString("X");
            return tid;
        }



        // equivalent to PHP mktime :
        public int GetUnixTimestamp(DateTime dt)
        {
            TimeSpan span = dt - new DateTime(1970, 1, 1);
            return (int)span.TotalSeconds;
        }

        public static string shieldsquare_IP2Hex(HttpRequest Request)
        {
            string hex = "00000000";
            
            string ip = Request.ServerVariables[ss2_config._ipaddress];
            
            //string ip = "11.22.34.46,21.21.21.21"; //TODO need to add server variables here
            char[] delimiters = new char[] { ',', '.' };
            //string[] part = Regex.Split(ip, ".,");
            string[] part = ip.Split(delimiters, StringSplitOptions.RemoveEmptyEntries);

            if (part.Length < 4)
            {
                return hex;
            }
            else 
            {
                hex = "";
            }

            for (int i = 0; i < 4; i++)
            {
                int decAgain = int.Parse(part[i], System.Globalization.NumberStyles.Integer);
                if (decAgain < 16) // Append a 0 to maintian 2 digits for every number
                {
                    hex += "0" + decAgain.ToString("X");
                }
                else
                {
                    hex += decAgain.ToString("X");
                }
            }

            return hex;
        }



    }
}