﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SS2WebApp
{
    public partial class sample_active : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            ss2 obj = new ss2();

            string shieldsquare_username = ""; // Enter the UserID of the user 
            int shieldsquare_calltype = 1;
            string shieldsquare_PID = "";


            ss2.shieldsquareResponse ssResponse = obj.ShieldSquare_ValidateRequest(base.Request, base.Response, shieldsquare_username, shieldsquare_calltype, shieldsquare_PID);
            if (ssResponse.responsecode == -1)
            {
                //"Exception has ocurred. Check the ssResponse.reason for the cause of the exception "; 
                shieldsquare_response.Value = "Please reach out to ShieldSquare support team for assistance" + ssResponse.reason;
            }
            if (ssResponse.responsecode == 0)
            {
                //"Display the Page"; 
                shieldsquare_response.Value = "Allow the user request";
            }

            if (ssResponse.responsecode == 1)
            {
                //"Monitor this Request";
                shieldsquare_response.Value = "Monitor this Traffic";
            }
            if (ssResponse.responsecode == 2)
            {
                // "Show CAPTCHA before displaying this page";
                shieldsquare_response.Value = "Show CAPTCHA before displaying the content";
            }
            if (ssResponse.responsecode == 3)
            {
                // "Block This request"; 
                shieldsquare_response.Value = "Block This request";
            }
            if (ssResponse.responsecode == 4)
            {
                // "Block This request"; 
                shieldsquare_response.Value = "Feed Fake Data";
            }
            //copy the value of the tid to a hidden field shieldsquare_response_tid in the asp page.
            //This field can be used to pass the value to the IFRAME

            shieldsquare_response_PID.Value = ssResponse.pid;
            shieldsquare_response_url.Value = ssResponse.url;
            shieldsquare_response_js.Value = ssResponse.dynamic_js;
        }
    }
}