﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml;
using System.Configuration;


namespace SS2WebApp
{
    class HeaderData
    {
        public string Key { get; set; }
        public int Index { get; set; }
        public string Value { get; set; }
    };
    public class ss2_config
    {
        /*
	     *  Enter your SID .
	    */
        public static string _sid = "";

        /*
         * Mode = Active,Monitor
        */

        public static string _mode = "";

        /*
         * Async_htp_post
        */

        public static bool _async_http_post = false;

        /*
         * Timeout in Seconds or Milliseconds depends on Timeout type
         */

        public static int _timeout_value = 0;

        public static int _timeout_type = 0;

        /*
         * ASP.NET_SessionId is the default session ID for ASP.NET, please change it if needed
        */
        public static string _sessid = "";

        /*
         * Change this value if your servers are behind a firewall or proxy
        */
        public static string _ipaddress = "";


        /*
	     * Enter the URL fo the JavaScript Data Collector
	    */
        public static string _js_url = "";

        /*
         * Set the ShieldSquare domain based on your Server Locations
        *    East US        - ss_eus.shieldsquare.net
        *    West US        - ss_wus.shieldsquare.net
        *    India/Asia     - ss_sa.shieldsquare.net
        *    North Europe   - ss_ne.shieldsquare.net
        *    West Europe    - ss_we.shieldsquare.net
        */

        public static string _ss2_domain = "";


        static ss2_config()
            {
                    _sid = ConfigurationManager.AppSettings["sid"];
                    _mode = ConfigurationManager.AppSettings["mode"];
                    _async_http_post = Convert.ToBoolean(ConfigurationManager.AppSettings["async_http_post"]);
                    _timeout_value = Convert.ToInt16(ConfigurationManager.AppSettings["timeout_value"]);
                    _timeout_type = Convert.ToInt16(ConfigurationManager.AppSettings["timeout_type"]);
                    _sessid = ConfigurationManager.AppSettings["sessid"];
                    _ipaddress = ConfigurationManager.AppSettings["ipaddress"];
                    _js_url = ConfigurationManager.AppSettings["js_url"];
                    _ss2_domain = ConfigurationManager.AppSettings["ss2_domain"];
                    ConfigurationManager.RefreshSection("appSettings");       
            }
   
 
    }

  
}