﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Diagnostics;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;


using System.IO;
using System.Net;
using System.Text;


namespace SS2WebApp
{

    class JSRequest
    {
        String jsRequest;
        public string id { get; set; }
    }

    /// <summary>
    /// Summary description for getData
    /// </summary>
    public class getData : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            
            string shieldsquare_service_url = "http://" + ss2_config._ss2_domain + "/getss2data";
            
            string json = context.Request["jsonString"];
            if(json!="")
            {
                JObject o = JObject.Parse(json);
                string sid = ss2_config._sid;
                string ip = context.Request.ServerVariables[ss2_config._ipaddress] != null ? context.Request.ServerVariables[ss2_config._ipaddress] : "";
                o.Add("sid", sid);
                o.Add("host", ip);
                ss2 obj = new ss2();
                json = o.ToString();
                
                if (ss2_config._async_http_post == true)
                {
                    string[] shieldsquarePostResponse = obj.HttpAsyncPost(shieldsquare_service_url, json);
                }
                else
                {
                    string[] shieldsquarePostResponse = obj.HttpSyncPost(shieldsquare_service_url, json);
                }
                context.Response.ContentType = "text/plain";
                context.Response.Write("request received :" + json);
            }

        }


        public bool IsReusable
        {
            get
            {
                return false;
            }
        }

    }



}