#!/usr/bin/python2.7
# Code Sinppet-1 for Shield Square
import ss2

shieldsquare_userid = "" # Enter the UserID of the user
shieldsquare_calltype = 1
shieldsquare_pid = ""
shieldsquare_response=ss2.shieldsquare_ValidateRequest(shieldsquare_userid, shieldsquare_calltype, shieldsquare_pid);


print "Content-type: text/html\n\n"
print '''
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="Content-Language" content="en" />
<title>Sample Home Page</title>
</head>
<body>
'''
if(shieldsquare_response['responsecode'] == -1):
	print "Curl Error - " + shieldsquare_response['reason'] + "<BR>";
	print "Please reach out to ShieldSquare support team for assistance <BR>";
	print "Allow the user request";
#<!--  Code Sinppet-1 for Shield Square  -->
print '<script type="text/javascript">'
print 'var __uzdbm_a = "' + shieldsquare_response['pid'] + '";'
print 'var __uzdbm_b = "' + shieldsquare_response['url'] + '";'
print shieldsquare_response['dynamic_JS']
print '''
</script>
<script type="text/javascript" src="http://cdn.perfdrive.com/static/browser_detect_min.js"></script>
<h1>
<BR>YOUR CODE GOES HERE
</h1>
</body>
</html>
'''
