#!/usr/bin/python2.7

#print ""
#print "\n"#Enter your SID
_sid = "XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX"

#Please specify the mode in which you want to operate
#mode = "Active";
#mode = "Monitor";
_mode = 'Active'

#Asynchronous HTTP Data Post  
#Setting this value to true will reduce the page load time when you are in Monitor mode. 
#This uses Linux CURL to POST the HTTP data using the EXEC command. 
#Note: Enable this only if you are hosting your applications on Linux environments. 
_async_http_post = 'true'

#* Timeout in Seconds or Milliseconds (based on the  $_timeout_type value)
_timeout_value = 700

_timeout_type = 0

#* PHPSESSID is the default session ID for PHP, please change it if needed
_sessid = 'SESSID'

#* Change this value if your servers are behind a firewall or proxy
_ipaddress = 'REMOTE_ADDR'

#* Enter the URL fo the JavaScript Data Collector
_py_url = '/getData.py'

#* Set the ShieldSquare domain based on your Server Locations
#*    East US        - ss_eus.shieldsquare.net
#*    West US        - ss_wus.shieldsquare.net
#*    India/Asia     - ss_sa.shieldsquare.net
#*    North Europe   - ss_ne.shieldsquare.net
#*    West Europe    - ss_we.shieldsquare.net
#_ss2_domain = 'ss_sa.shieldsquare.net'
_ss2_domain = 'prod-cfm1-sa.cloudapp.net:7080'


