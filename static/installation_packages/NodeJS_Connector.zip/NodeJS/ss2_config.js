function shieldsquare_config()
{
	/*
	 *  Enter your SID .
	*/
	this._sid = "a9dfb465-ba57-2503-2bc1-56c387484132";

	/*

	 * Please specify the mode in which you want to operate
	 * 
	 * public $_mode = "Active";
	 * or
	 * public $_mode = "Monitor";
 	 */
	this._mode = "Active";
	
   /*
    * Asyncronus HTTP Data Post  
    * This uses Linux CURL to POST the HTTP data using the EXEC command. 
    * Setting this to true will drastically reduce the page load time when you are in Monitor mode
    * Note: Enable this only if you are running on applications on Linux environments.   
    */
	this._async_http_post = true;
	
	/*
	 * Curl Timeout in Milliseconds
	 */
	this._timeout_value = 1000;

	/*
	 * PHPSESSID is the default session ID for Node, please change it if needed
	*/
	this._sessid = 'SESSID';

	/*
	 * Enter the URL fo the JavaScript Data Collector
	*/
	this._js_url = '/getData';

	/*
	 * Set the ShieldSquare domain based on your Server Locations
	 *    US/Europe    	-    'ss_scus.shieldsquare.net'
	 *    India/Asia    -    'ss_sa.shieldsquare.net'
	 */
	this._ss2_domain = 'ss_sa.shieldsquare.net';
}

module.exports = shieldsquare_config;