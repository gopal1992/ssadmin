var express = require('express');
var bodyParser = require('body-parser');
var util = require("./ss2");
var getData = require("./getData");
var shieldsquare_util = new util();

var app = express();
app.use(bodyParser());

app.get('/test', function(req, res){
	$shieldsquare_userid = ""; // Enter the UserID of the user
	$shieldsquare_calltype = 1;
	$shieldsquare_pid = "";
	//It will be like blocking call
	shieldsquare_util.shieldsquare_ValidateRequest($shieldsquare_userid, $shieldsquare_calltype, $shieldsquare_pid, req, res, function(shieldsquare_response){
		//Got output here
		console.log("Inside Async::"+JSON.stringify(shieldsquare_response));
		if (shieldsquare_response.responsecode == 0)
			console.log("Allow the user request");
		else if (shieldsquare_response.responsecode == 1)
			console.log("Monitor this Traffic");
		else if (shieldsquare_response.responsecode == 2)
			console.log("Show CAPTCHA before displaying the content");
		else if (shieldsquare_response.responsecode == 3)
			console.log("Block This request");
		else if (shieldsquare_response.responsecode == 4)
			console.log("Feed Fake Data");
		else if (shieldsquare_response.responsecode == -1)
		{
			console.log("Curl Error - " + shieldsquare_response.reason + "<BR>");
			console.log("Please reach out to ShieldSquare support team for assistance <BR>");
			console.log("Allow the user request");
		}
		
		app.set('views', __dirname + '/views');
		app.set('view engine', 'jade');
		res.render('index',{captcha:shieldsquare_response.dynamic_JS,pid:shieldsquare_response.pid,url:shieldsquare_response.url});
	});
	
});

app.post('/getData', function(req, res){
	var getD = new getData(req.body.jsonString, req);
	res.send("Output will come here");
});

app.listen(3000);
console.log("App listening 3000");
