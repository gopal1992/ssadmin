var config = require("./ss2_config");
var util = require("./ss2");
var shieldsquare_config = new config();
var shieldsquare_util = new util();

function shieldGetData(params, req){
	shieldsquare_service_url = "http://"+shieldsquare_config._ss2_domain+"/getRequestData";
	shieldsquare_request = JSON.parse (params);
	shieldsquare_request.sid = shieldsquare_config._sid;
	shieldsquare_request.host = req.connection.remoteAddress || req.socket.remoteAddress || req.connection.socket.remoteAddress;
	//console.log("AA:::"+JSON.stringify(shieldsquare_request));
	shieldsquare_post_data = shieldsquare_request;
	if (shieldsquare_config._async_http_post === true)
	{
		shieldsquare_util.shieldsquare_post_async(shieldsquare_service_url, shieldsquare_post_data, function(response){
			//console.log("Inside resp::"+JSON.stringify(response));
			console.log(response.error_string);
		} );
		
	}else{
		shieldsquare_util.shieldsquare_post_sync(shieldsquare_service_url, shieldsquare_post_data,shieldsquare_config._timeout_value, function(response){
			console.log( response.error_string);
		});
	}
}
module.exports = shieldGetData;