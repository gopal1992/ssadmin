var http = require('http');
var sync = require('http-sync');

http.createServer(function (request, response) {
	var request = httpSync.request({
		method: 'GET',
		headers: {},
		body: '',

		protocol: 'http',
		host: 'http://www.wizdommind.com',
		port: 80, //443 if protocol = https
		path: '/'
	});
	var response = request.end();
	console.log(response.body.toString());
}).listen(8124);

console.log('Server running at http://127.0.0.1:8124/');