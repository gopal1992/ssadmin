var http = require('http');
var util = require("./ss2");
var shieldsquare_util = new util();

http.createServer(function (request, response) {
	$shieldsquare_userid = ""; // Enter the UserID of the user
	$shieldsquare_calltype = 1;
	$shieldsquare_pid = "";
	shieldsquare_util.shieldsquare_ValidateRequest($shieldsquare_userid, $shieldsquare_calltype, $shieldsquare_pid, request, response, function(shieldsquare_response){
		//Got output here
		console.log("Inside Async::"+JSON.stringify(shieldsquare_response));
	});	
	response.writeHead(200, {'Content-Type': 'text/plain'});
	response.end('Hello World\n');
}).listen(8124);

console.log('Server running at http://127.0.0.1:8124/');