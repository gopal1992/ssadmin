var request = require('request');
var Cookies = require('cookies');

var config = require("./ss2_config");
var shieldsquare_config = new config();

function shieldsquareRequest()
{
	this._zpsbd0 = false;
	this._zpsbd1 = "";
	this._zpsbd2 = "";
	this._zpsbd3 = "";
	this._zpsbd4 = "";
	this._zpsbd5 = "";
	this._zpsbd6 = "";
	this._zpsbd7 = "";
	this._zpsbd8 = "";
	this._zpsbd9 = "";
	this._zpsbda = "";
	this.__uzma = "";
	this.__uzmb = 0;
	this.__uzmc = "";
	this.__uzmd = 0;
}

function shieldsquareCurlResponseCode()
{
	this.error_string = "";
	this.responsecode = 0;
}

function shieldsquareResponse()
{
	this.pid = "";
	this.responsecode;
	this.url = "";
	this.reason ="";
}

function shieldsquareCodes()
{
	this.ALLOW   = 0;
	this.MONITOR = 1;
	this.CAPTCHA = 2;
	this.BLOCK   = 3;
	this.ALLOW_EXP = -1;
}

function microtime(get_as_float) {
  var now = new Date().getTime() / 1000;
  var s = parseInt(now, 10);
  return (get_as_float) ? now : (Math.round((now - s) * 1000) / 1000) + ' ' + s;
}

function dechex(dec){
	var str = "0"+parseInt(dec).toString(16);
	str.substr(str.length-2);
	return str;
}

function hexdec(hex){
	return parseInt(hex,16);
}

function mt_rand(min, max) {
  //  discuss at: http://phpjs.org/functions/mt_rand/
  // original by: Onno Marsman
  // improved by: Brett Zamir (http://brett-zamir.me)
  //    input by: Kongo
  //   example 1: mt_rand(1, 1);
  //   returns 1: 1

  var argc = arguments.length;
  if (argc === 0) {
	min = 0;
	max = 2147483647;
  } else if (argc === 1) {
	throw new Error('Warning: mt_rand() expects exactly 2 parameters, 1 given');
  } else {
	min = parseInt(min, 10);
	max = parseInt(max, 10);
  }
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function sprintf() {
  //  discuss at: http://phpjs.org/functions/sprintf/
  // original by: Ash Searle (http://hexmen.com/blog/)
  // improved by: Michael White (http://getsprink.com)
  // improved by: Jack
  // improved by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
  // improved by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
  // improved by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
  // improved by: Dj
  // improved by: Allidylls
  //    input by: Paulo Freitas
  //    input by: Brett Zamir (http://brett-zamir.me)
  //   example 1: sprintf("%01.2f", 123.1);
  //   returns 1: 123.10
  //   example 2: sprintf("[%10s]", 'monkey');
  //   returns 2: '[    monkey]'
  //   example 3: sprintf("[%'#10s]", 'monkey');
  //   returns 3: '[####monkey]'
  //   example 4: sprintf("%d", 123456789012345);
  //   returns 4: '123456789012345'
  //   example 5: sprintf('%-03s', 'E');
  //   returns 5: 'E00'

  var regex = /%%|%(\d+\$)?([-+\'#0 ]*)(\*\d+\$|\*|\d+)?(\.(\*\d+\$|\*|\d+))?([scboxXuideEfFgG])/g;
  var a = arguments;
  var i = 0;
  var format = a[i++];

  // pad()
  var pad = function (str, len, chr, leftJustify) {
	if (!chr) {
	  chr = ' ';
	}
	var padding = (str.length >= len) ? '' : new Array(1 + len - str.length >>> 0)
	  .join(chr);
	return leftJustify ? str + padding : padding + str;
  };

  // justify()
  var justify = function (value, prefix, leftJustify, minWidth, zeroPad, customPadChar) {
	var diff = minWidth - value.length;
	if (diff > 0) {
	  if (leftJustify || !zeroPad) {
		value = pad(value, minWidth, customPadChar, leftJustify);
	  } else {
		value = value.slice(0, prefix.length) + pad('', diff, '0', true) + value.slice(prefix.length);
	  }
	}
	return value;
  };

  // formatBaseX()
  var formatBaseX = function (value, base, prefix, leftJustify, minWidth, precision, zeroPad) {
	// Note: casts negative numbers to positive ones
	var number = value >>> 0;
	prefix = prefix && number && {
	  '2': '0b',
	  '8': '0',
	  '16': '0x'
	}[base] || '';
	value = prefix + pad(number.toString(base), precision || 0, '0', false);
	return justify(value, prefix, leftJustify, minWidth, zeroPad);
  };

  // formatString()
  var formatString = function (value, leftJustify, minWidth, precision, zeroPad, customPadChar) {
	if (precision != null) {
	  value = value.slice(0, precision);
	}
	return justify(value, '', leftJustify, minWidth, zeroPad, customPadChar);
  };

  // doFormat()
  var doFormat = function (substring, valueIndex, flags, minWidth, _, precision, type) {
	var number, prefix, method, textTransform, value;

	if (substring === '%%') {
	  return '%';
	}

	// parse flags
	var leftJustify = false;
	var positivePrefix = '';
	var zeroPad = false;
	var prefixBaseX = false;
	var customPadChar = ' ';
	var flagsl = flags.length;
	for (var j = 0; flags && j < flagsl; j++) {
	  switch (flags.charAt(j)) {
	  case ' ':
		positivePrefix = ' ';
		break;
	  case '+':
		positivePrefix = '+';
		break;
	  case '-':
		leftJustify = true;
		break;
	  case "'":
		customPadChar = flags.charAt(j + 1);
		break;
	  case '0':
		zeroPad = true;
		customPadChar = '0';
		break;
	  case '#':
		prefixBaseX = true;
		break;
	  }
	}

	// parameters may be null, undefined, empty-string or real valued
	// we want to ignore null, undefined and empty-string values
	if (!minWidth) {
	  minWidth = 0;
	} else if (minWidth === '*') {
	  minWidth = +a[i++];
	} else if (minWidth.charAt(0) == '*') {
	  minWidth = +a[minWidth.slice(1, -1)];
	} else {
	  minWidth = +minWidth;
	}

	// Note: undocumented perl feature:
	if (minWidth < 0) {
	  minWidth = -minWidth;
	  leftJustify = true;
	}

	if (!isFinite(minWidth)) {
	  throw new Error('sprintf: (minimum-)width must be finite');
	}

	if (!precision) {
	  precision = 'fFeE'.indexOf(type) > -1 ? 6 : (type === 'd') ? 0 : undefined;
	} else if (precision === '*') {
	  precision = +a[i++];
	} else if (precision.charAt(0) == '*') {
	  precision = +a[precision.slice(1, -1)];
	} else {
	  precision = +precision;
	}

	// grab value using valueIndex if required?
	value = valueIndex ? a[valueIndex.slice(0, -1)] : a[i++];

	switch (type) {
	case 's':
	  return formatString(String(value), leftJustify, minWidth, precision, zeroPad, customPadChar);
	case 'c':
	  return formatString(String.fromCharCode(+value), leftJustify, minWidth, precision, zeroPad);
	case 'b':
	  return formatBaseX(value, 2, prefixBaseX, leftJustify, minWidth, precision, zeroPad);
	case 'o':
	  return formatBaseX(value, 8, prefixBaseX, leftJustify, minWidth, precision, zeroPad);
	case 'x':
	  return formatBaseX(value, 16, prefixBaseX, leftJustify, minWidth, precision, zeroPad);
	case 'X':
	  return formatBaseX(value, 16, prefixBaseX, leftJustify, minWidth, precision, zeroPad)
		.toUpperCase();
	case 'u':
	  return formatBaseX(value, 10, prefixBaseX, leftJustify, minWidth, precision, zeroPad);
	case 'i':
	case 'd':
	  number = +value || 0;
	  // Plain Math.round doesn't just truncate
	  number = Math.round(number - number % 1);
	  prefix = number < 0 ? '-' : positivePrefix;
	  value = prefix + pad(String(Math.abs(number)), precision, '0', false);
	  return justify(value, prefix, leftJustify, minWidth, zeroPad);
	case 'e':
	case 'E':
	case 'f': // Should handle locales (as per setlocale)
	case 'F':
	case 'g':
	case 'G':
	  number = +value;
	  prefix = number < 0 ? '-' : positivePrefix;
	  method = ['toExponential', 'toFixed', 'toPrecision']['efg'.indexOf(type.toLowerCase())];
	  textTransform = ['toString', 'toUpperCase']['eEfFgG'.indexOf(type) % 2];
	  value = prefix + Math.abs(number)[method](precision);
	  return justify(value, prefix, leftJustify, minWidth, zeroPad)[textTransform]();
	default:
	  return substring;
	}
  };

  return format.replace(regex, doFormat);
}

function uniqid(prefix, more_entropy) {
  //  discuss at: http://phpjs.org/functions/uniqid/
  // original by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
  //  revised by: Kankrelune (http://www.webfaktory.info/)
  //        note: Uses an internal counter (in php_js global) to avoid collision
  //        test: skip
  //   example 1: uniqid();
  //   returns 1: 'a30285b160c14'
  //   example 2: uniqid('foo');
  //   returns 2: 'fooa30285b1cd361'
  //   example 3: uniqid('bar', true);
  //   returns 3: 'bara20285b23dfd1.31879087'

  if (typeof prefix === 'undefined') {
    prefix = '';
  }

  var retId;
  var formatSeed = function (seed, reqWidth) {
    seed = parseInt(seed, 10)
      .toString(16); // to hex str
    if (reqWidth < seed.length) {
      // so long we split
      return seed.slice(seed.length - reqWidth);
    }
    if (reqWidth > seed.length) {
      // so short we pad
      return Array(1 + (reqWidth - seed.length))
        .join('0') + seed;
    }
    return seed;
  };

  // BEGIN REDUNDANT
  if (!this.php_js) {
    this.php_js = {};
  }
  // END REDUNDANT
  if (!this.php_js.uniqidSeed) {
    // init seed with big random int
    this.php_js.uniqidSeed = Math.floor(Math.random() * 0x75bcd15);
  }
  this.php_js.uniqidSeed++;

  // start with prefix, add current milliseconds hex string
  retId = prefix;
  retId += formatSeed(parseInt(new Date()
    .getTime() / 1000, 10), 8);
  // add seed hex string
  retId += formatSeed(this.php_js.uniqidSeed, 5);
  if (more_entropy) {
    // for more entropy we add a float lower to 10
    retId += (Math.random() * 10)
      .toFixed(8)
      .toString();
  }

  return retId;
}

function shieldsquareUtility(){
	this.shieldsquare_ValidateRequest = function(shieldsquare_username, shieldsquare_calltype, shieldsquare_pid, request, response, maincallback)
	{
		var shieldsquare_low  = 10000;
		var shieldsquare_high = 99999;
		var shieldsquare_a = 1;
		var shieldsquare_b = 3;
		var shieldsquare_c = 7;
		var shieldsquare_d = 1;
		var shieldsquare_e = 5;
		var shieldsquare_f = 10;
		var shieldsquare_time = new Date();

		shieldsquare_request = new shieldsquareRequest();
		shieldsquare_RETURNCODES = new shieldsquareCodes();
		shieldsquare_response = new shieldsquareResponse();
		shieldsquare_curl_response = new shieldsquareCurlResponseCode;
		shieldsquare_service_url = "http://"+shieldsquare_config._ss2_domain+"/getRequestData";

		var curl_timeout = 1;
		if(shieldsquare_config._timeout_value > 1000)
		{
			console.log("ShieldSquare Timeout cant be greater then 1000 milli seconds");
			exit;
		}else{
			curl_timeout = shieldsquare_config._timeout_value;
		}
			

		if(shieldsquare_calltype == 1)
			shieldsquare_pid = this.shieldsquare_generate_pid(shieldsquare_config._sid, request);
		else
		{
			if (strlen(shieldsquare_pid)== 0)
			{
				console.log("PID Cant be null");
				exit;
			}

		}
		
		var shieldsquare_ex_time = shieldsquare_time + 3600 * 24 * 365 * 10;
		var cookies = new Cookies( request, response);
		//cookies.set( "__uzma","testSrini");
		var __uzma = cookies.get("__uzma");
		if(__uzma != undefined && __uzma != "")
		{
			shieldsquare_lastaccesstime =  cookies.get("__uzmd");
			if(shieldsquare_lastaccesstime != ""){
				shieldsquare_lastaccesstime = new Date(shieldsquare_lastaccesstime);
			}
			shieldsquare_uzmc= (cookies.get("__uzmc") != undefined)?cookies.get("__uzmc"):0;
			if(shieldsquare_uzmc != 0){
				shieldsquare_uzmc=shieldsquare_uzmc.substr(shieldsquare_e,shieldsquare_uzmc.length-shieldsquare_f);
			}
			shieldsquare_a = parseInt(shieldsquare_uzmc-shieldsquare_c)/shieldsquare_b + shieldsquare_d;
			shieldsquare_uzmc= mt_rand(shieldsquare_low, shieldsquare_high)+""+(shieldsquare_c+shieldsquare_a*shieldsquare_b)+""+mt_rand(shieldsquare_low, shieldsquare_high)+"";
			shieldsquare_ex_time =new Date(shieldsquare_time.setTime(shieldsquare_time.getTime()+(365*24*60*60*1000)));
			cookies.set("__uzmc",shieldsquare_uzmc,{'expires':shieldsquare_ex_time});
			cookies.set("__uzmd",shieldsquare_time,{'expires':shieldsquare_ex_time});
			shieldsquare_request.__uzma = cookies.get("__uzma");
			shieldsquare_request.__uzmb = cookies.get("__uzmb");
			shieldsquare_request.__uzmc = shieldsquare_uzmc;
			shieldsquare_request.__uzmd = shieldsquare_lastaccesstime.getTime();
			cookies.set( "__uzmc",shieldsquare_uzmc, {expires:shieldsquare_ex_time} );
			cookies.set( "__uzmc",shieldsquare_time, {expires:shieldsquare_ex_time} );
		}
		else
		{
			shieldsquare_uzma = uniqid('', true);
			shieldsquare_lastaccesstime = shieldsquare_time;
			shieldsquare_uzmc= mt_rand(shieldsquare_low, shieldsquare_high)+""+(shieldsquare_c+shieldsquare_a*shieldsquare_b)+""+mt_rand(shieldsquare_low, shieldsquare_high)+"";
			shieldsquare_ex_time =new Date(shieldsquare_time.setTime(shieldsquare_time.getTime()+(365*24*60*60*1000)));
			cookies.set("__uzma",shieldsquare_uzma,{'expires':shieldsquare_ex_time});
			cookies.set("__uzmb",shieldsquare_time.getTime(),{'expires':shieldsquare_ex_time});
			cookies.set("__uzmc",shieldsquare_uzmc,{'expires':shieldsquare_ex_time});
			cookies.set("__uzmd",shieldsquare_time.getTime(),{'expires':shieldsquare_ex_time});
			shieldsquare_request.__uzma = shieldsquare_uzma;
			shieldsquare_request.__uzmb = shieldsquare_time;
			shieldsquare_request.__uzmc = shieldsquare_uzmc;
			shieldsquare_request.__uzmd = shieldsquare_lastaccesstime.getTime();
		}
		shieldsquare_request._zpsbd0 = false;
		if (shieldsquare_config._mode == "Active")
			shieldsquare_request._zpsbd0 = true;
		shieldsquare_request._zpsbd1 = shieldsquare_config._sid;
		shieldsquare_request._zpsbd2 = shieldsquare_pid;
		shieldsquare_request._zpsbd3 = (request.headers['referer'] != undefined) ? request.headers['referer'] : '';
		shieldsquare_request._zpsbd4 = (request.url != undefined) ? request.url : '';
		shieldsquare_request._zpsbd5 = cookies.get(shieldsquare_config._sessid) != undefined ? cookies.getshieldsquare_config._sessid : '';
		shieldsquare_request._zpsbd6 = request.connection.remoteAddress || request.socket.remoteAddress || request.connection.socket.remoteAddress || '';
		shieldsquare_request._zpsbd7 = (request.headers['user-agent'] != undefined) ? request.headers['user-agent'] : '';
		shieldsquare_request._zpsbd8 = shieldsquare_calltype;
		shieldsquare_request._zpsbd9 = shieldsquare_username;
		shieldsquare_request._zpsbda = shieldsquare_time.getTime();
		shieldsquare_json_obj = shieldsquare_request;

		shieldsquare_response.pid =shieldsquare_pid;
		shieldsquare_response.url =shieldsquare_config._js_url;

		if(shieldsquare_config._mode == "Active")
		{
			this.shieldsquare_post_sync(shieldsquare_service_url, shieldsquare_json_obj, curl_timeout, function(shieldsquare_curl_response){
				//console.log("AA:::"+JSON.stringify(shieldsquare_curl_response));
				if(shieldsquare_curl_response.responsecode === false)
				{
					shieldsquare_response.responsecode = shieldsquare_RETURNCODES.ALLOW_EXP;
					shieldsquare_response.reason = shieldsquare_curl_response.error_string;
				}
				else
				{
					shieldsquare_response_from_ss = shieldsquare_curl_response.responsecode;
					shieldsquare_response.dynamic_JS = shieldsquare_response_from_ss.dynamic_JS;
					switch(parseInt(shieldsquare_response_from_ss.ssresp))
					{
						case 0:
							shieldsquare_response.responsecode = shieldsquare_RETURNCODES.ALLOW;
							break;
						case 1:
							shieldsquare_response.responsecode = shieldsquare_RETURNCODES.MONITOR;
							break;
						case 2:
							shieldsquare_response.responsecode = shieldsquare_RETURNCODES.CAPTCHA;
							break;
						case 3:
							shieldsquare_response.responsecode = shieldsquare_RETURNCODES.BLOCK;
							break;
						case 4:
							shieldsquare_response.responsecode = shieldsquare_RETURNCODES.FFD;
							break;
						default:
							shieldsquare_response.responsecode = shieldsquare_RETURNCODES.ALLOW_EXP;
							shieldsquare_response.reason = shieldsquare_curl_response.error_string;
							break;
					}
				}
				maincallback(shieldsquare_response);
			});
		}
		else
		{
			if(shieldsquare_config._async_http_post === true)
			{
				this.shieldsquare_post_async(shieldsquare_service_url, shieldsquare_json_obj, function(shieldsquare_curl_response){
					if(shieldsquare_curl_response.responsecode===-1||shieldsquare_curl_response.responsecode===false)
					{
						shieldsquare_response.responsecode = shieldsquare_RETURNCODES.ALLOW_EXP;
					}
					else
					{
						shieldsquare_response.responsecode = shieldsquare_RETURNCODES.ALLOW ;
					}
					maincallback(shieldsquare_response);
				});
				
			}
			else
			{
				shieldsquare_curl_response=this.shieldsquare_post_sync(shieldsquare_service_url, shieldsquare_json_obj,curl_timeout, function(shieldsquare_curl_response){
					if(shieldsquare_curl_response.responsecode === false)
					{
						shieldsquare_response.responsecode = shieldsquare_RETURNCODES.ALLOW_EXP;
						shieldsquare_response.reason = shieldsquare_curl_response.error_string;
					}
					else
					{
						shieldsquare_response.responsecode = shieldsquare_RETURNCODES.ALLOW ;
					}
					maincallback(shieldsquare_response);
				});
			}
			shieldsquare_response.dynamic_JS = "var __uzdbm_c = 2+2";
		}
		//maincallback(shieldsquare_response);
	}

	this.shieldsquare_post_async = function(url, params, callback)
	{
		shieldsquare_curl_response = new shieldsquareCurlResponseCode;
		
		request.post({
			headers: {'content-type' : 'application/json'},
			url : url,
			json : params
			},
			function (error, response, body) {
				if (!error && response.statusCode == 200) {
					shieldsquare_curl_response.responsecode = body;
					callback(shieldsquare_curl_response);
				}
			}
		);
	}

	this.shieldsquare_post_sync = function(url, params, timeout, callback)
	{
		// Sending the Data to the ShieldSquare Server 
		shieldsquare_curl_response = new shieldsquareCurlResponseCode;
		
		request.post({
			headers: {'content-type' : 'application/json'},
			url : url,
			json : params,
			timeout : timeout,
			},
			function (error, response, body) {
				if (!error && response.statusCode == 200) {
					shieldsquare_curl_response.responsecode = body;
					callback(shieldsquare_curl_response);
				}
			}
		);
	}

	this.shieldsquare_IP2Hex = function(req)
	{
		hex="";
		ip = req.connection.remoteAddress || req.socket.remoteAddress || req.connection.socket.remoteAddress;
		//console.log("IP::"+ip);
		part=ip.split('.');
		for (i=0; i<part.length; i++) {
			hex+=dechex(part[i]);
		}
		return hex;
	}
	
	this.shieldsquare_generate_pid = function(shieldsquare_sid, request)
	{
		t=(microtime(0)+"").split(" ");
		var arr = shieldsquare_sid.split("-");
		sid_min = num = hexdec(arr[3]);
		
		//console.log("AA::"+dechex(t[1])+"=="+mt_rand(0,0xffff));

		return sprintf( '%08s-%04x-%04s-%04s-%04x%04x%04x',
				this.shieldsquare_IP2Hex(request),
				sid_min,
				("00000000"+dechex(t[1])).substr(-4),
				("0000"+dechex(Math.round(t[0]*65536))).substr(-4),
				mt_rand(0,0xffff), mt_rand(0,0xffff), mt_rand(0,0xffff));
	}
	
	/*this.shieldsquare_post_async('http://ip-api.com/json', function(resp){
		console.log("Async GET::"+resp);
	});
	this.shieldsquare_post_sync('http://ip-api.com/json',null, 10, function(resp){
		console.log("Post::"+resp);
	});
	*/
}
module.exports = shieldsquareUtility;
//console.log("BB::"+shieldsquare_config._sid+"==="+shieldsquare_generate_pid(shieldsquare_config._sid));